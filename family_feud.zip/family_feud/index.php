<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="javascript.js" defer></script>
    <title>Family Feud</title>
</head>
<body>
    <div class="game-container">
        <h1>Family Feud Game</h1>

        <!-- Start Game Button -->
        <button id="start-game" onclick="startGame()">Start Game</button>

        <div id="question-container">
            <!-- Questions and answers dynamically loaded by JavaScript -->
        </div>

        <!-- Input for Answer by the team who pressed the buzzer -->
        <div id="answer-section" style="display:none;">
            <input type="text" id="answer-input" placeholder="Type your answer" />
            <button onclick="submitAnswer()">Submit Answer</button>
        </div>

        <div class="buzzer-section" style="display: none;">
            <img id="team1-buzzer" src="assets/image/buzzerrr.png" alt="Team 1 Buzzer" onclick="buzz(1)">
            <img id="team2-buzzer" src="assets/image/buzzerrr.png" alt="Team 2 Buzzer" onclick="buzz(2)">
        </div>

        <div class="scoreboard">
            <div>Team 1: <span id="team1-score">0</span></div>
            <div>Team 2: <span id="team2-score">0</span></div>
        </div>

        <div id="timer">Time: <span id="time">10</span>s</div>
        <div id="winner"></div>

        <!-- Section for Revealed Answers -->
        <div id="revealed-answers" style="margin-top: 20px;"></div>

        <!-- Leaderboard Section -->
        <div id="leaderboard" style="margin-top: 20px;">
            <h2>Leaderboard</h2>
            <div id="leaderboard-container">
                <?php
                include 'data/config_file.php'; // Include the connection file
                
                // Fetch leaderboard data
                $sql = "SELECT team, final_score FROM winners ORDER BY final_score DESC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<div>{$row['team']}: {$row['final_score']}</div>";
                    }
                } else {
                    echo "<div>No winners yet!</div>";
                }

                $conn->close(); // Close the connection
                ?>
            </div>
        </div>

        <audio id="game-audio" loop>
            <source src="assets/audio/Family Feud PH - Fast Money Music (2022).mp3" type="audio/mpeg">
            Your browser does not support the audio element.
        </audio>
    </div>
</body>
</html>
