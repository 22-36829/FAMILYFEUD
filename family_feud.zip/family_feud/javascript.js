let questions = [
    {
        question: "Mahirap maging (blank).",
        answers: { "Pogi": 60, "Mahirap": 7, "Mabait": 4, "Pangit": 4, "Single": 3 }
    },
    {
        question: "Magbigay ng salitang pwedeng pang-describe sa saging?",
        answers: { "Mahaba": 43, "Masarap": 10, "Matamis": 10, "Dilaw": 6, "Malambot": 4, "Kurbado": 4 }
    },
    {
        question: "Anong kulay ang saging kapag hinog na?",
        answers: { "Dilaw": 50, "Berde": 10, "Pula": 5 }
    },
    {
        question: "Anong uri ng prutas ang may balat na makinis?",
        answers: { "Mansanas": 40, "Saging": 20, "Pakwan": 15 }
    },
    {
        question: "Ano ang pinakapaboritong prutas ng mga Pilipino?",
        answers: { "Mangga": 45, "Saging": 30, "Pineapple": 25 }
    },
    {
        question: "Minsan, ano ang sagot sa mga problema?",
        answers: { "Tawa": 20, "Umiiyak": 10, "Sumasayaw": 15 }
    },
    {
        question: "Anong prutas ang may maraming buto?",
        answers: { "Pakwan": 30, "Mangga": 20, "Saging": 10 }
    },
    {
        question: "Anong uri ng saging ang madalas gamitin sa nilaga?",
        answers: { "Saba": 60, "Labanos": 10, "Latundan": 5 }
    },
    {
        question: "Saan galing ang saging?",
        answers: { "Puno": 50, "Hardin": 20, "Bahay": 10 }
    }
    // ... other questions
];

let currentQuestion = 0;
let team1Score = 0;
let team2Score = 0;
let strikes = 0;
let currentTeam = null; // No team starts by default
let totalTime = 60; // Each round duration in seconds
let roundTimer; // Variable for round timer
let teamHasControl = false; // Track if the team has control of the answer
let timerStarted = false; // Track if the timer has started

function loadQuestion() {
    let questionDiv = document.getElementById("question-container");
    questionDiv.innerHTML = `<h2>${questions[currentQuestion].question}</h2>`;
    strikes = 0; // Reset strikes when loading a new question
    teamHasControl = false; // Reset control for the next question
    timerStarted = false; // Reset the timer status for the new round
    document.getElementById("answer-section").style.display = "none"; // Hide answer section
    document.getElementById("revealed-answers").innerHTML = ""; // Clear previous answers
    enableBuzzers(); // Enable buzzers at the start of each round
    document.getElementById("time").innerText = totalTime; // Reset the timer display
}

function startGame() {
    // Play the audio when the game starts
    let audio = document.getElementById("game-audio");
    audio.play();
    
    document.getElementById("start-game").style.display = "none"; // Hide start button
    document.querySelector('.buzzer-section').style.display = "block"; // Show the buzzer section
    loadQuestion(); // Load the first question
}

function buzz(team) {
    if (!teamHasControl) {
        currentTeam = team;
        teamHasControl = true; // Set control to the team that buzzed first
        disableBuzzers(); // Disable both buzzers
        document.getElementById("answer-section").style.display = "block"; // Show the answer section for input
        console.log(`Team ${team} has buzzed!`);

        if (!timerStarted) {
            timerStarted = true; // Start the timer when the first buzzer is clicked
            startRoundTimer(); // Start the 1-minute countdown timer
        }
    }
}

function submitAnswer() {
    let answer = document.getElementById("answer-input").value.trim();
    checkAnswer(answer);
    document.getElementById("answer-input").value = ''; // Clear the input field after submission
}

function checkAnswer(answer) {
    if (!teamHasControl) return; // No team has buzzed, no one can answer

    let answerScore = questions[currentQuestion].answers[answer] || 0;
    if (answerScore > 0) {
        // Correct answer logic
        if (currentTeam === 1) {
            team1Score += answerScore;
            document.getElementById("team1-score").innerText = team1Score;
        } else {
            team2Score += answerScore;
            document.getElementById("team2-score").innerText = team2Score;
        }
        strikes = 0; // Reset strikes on a correct answer
        
        // Show the correct answer in the revealed answers section
        revealCorrectAnswer(answer, answerScore);
    } else {
        // Wrong answer logic
        strikes++;
        console.log(`Team ${currentTeam} guessed wrong. Strikes: ${strikes}`);
        
        if (strikes >= 3) {
            alert(`Team ${currentTeam} has 3 strikes! All points will be stolen by Team ${currentTeam === 1 ? 2 : 1}.`);
            stealPoints(); // Steal points from the current team to the opposing team and give control to the other team
        } else {
            alert(`Team ${currentTeam} guessed wrong. Strikes: ${strikes}.`);
        }
    }
    
    // Allow for another guess unless the team has reached 3 strikes
    if (strikes < 3) {
        document.getElementById("answer-section").style.display = "block"; // Allow the team to guess again
    }
}

// Function to reveal the correct answer
function revealCorrectAnswer(answer, score) {
    const revealedAnswersDiv = document.getElementById("revealed-answers");
    revealedAnswersDiv.innerHTML += `<div>${answer} (${score} points)</div>`; // Display the correct answer with its score
}


function stealPoints() {
    let otherTeam = currentTeam === 1 ? 2 : 1;
    let totalPoints = currentTeam === 1 ? team1Score : team2Score;
    
    if (otherTeam === 1) {
        team1Score += totalPoints;
        document.getElementById("team1-score").innerText = team1Score;
    } else {
        team2Score += totalPoints;
        document.getElementById("team2-score").innerText = team2Score;
    }
    
    // Reset the points of the current team
    if (currentTeam === 1) {
        team1Score = 0;
        document.getElementById("team1-score").innerText = team1Score;
    } else {
        team2Score = 0;
        document.getElementById("team2-score").innerText = team2Score;
    }

    // Switch control to the other team and allow them to play for the remaining time
    currentTeam = otherTeam;
    strikes = 0; // Reset strikes for the new team
    alert(`Now it's Team ${currentTeam}'s turn to play!`);
    document.getElementById("answer-section").style.display = "block"; // Show the answer section for the new team
}

function startRoundTimer() {
    let timeRemaining = totalTime;
    document.getElementById("time").innerText = timeRemaining;

    roundTimer = setInterval(() => {
        timeRemaining--;
        document.getElementById("time").innerText = timeRemaining;

        if (timeRemaining <= 0) {
            clearInterval(roundTimer);
            alert("Time's up! Ending round.");
            endRound(); // Automatically end the round if time runs out
        }
    }, 1000);
}

function endRound() {
    disableBuzzers(); // Disable buzzers for the current round
    clearInterval(roundTimer); // Ensure the timer stops
    if (currentQuestion < questions.length - 1) {
        currentQuestion++; // Load the next question
        loadQuestion();
    } else {
        endGame(); // End the game after all rounds
    }
}

function endGame() {
    clearInterval(roundTimer); // Stop the timer when the game ends
    
    // Stop the audio when the game ends
    let audio = document.getElementById("game-audio");
    audio.pause();
    audio.currentTime = 0; // Reset the audio to the start

    let winner;

    if (team1Score > team2Score) {
        winner = "Team 1";
    } else if (team2Score > team1Score) {
        winner = "Team 2";
    } else {
        winner = "It's a tie!";
    }

    document.getElementById("winner").innerText = `${winner} wins! Final Scores - Team 1: ${team1Score}, Team 2: ${team2Score}`;
}

function disableBuzzers() {
    document.getElementById("team1-buzzer").style.pointerEvents = "none";
    document.getElementById("team2-buzzer").style.pointerEvents = "none";
}

function enableBuzzers() {
    document.getElementById("team1-buzzer").style.pointerEvents = "auto";
    document.getElementById("team2-buzzer").style.pointerEvents = "auto";
}
