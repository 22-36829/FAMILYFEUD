<?php
include 'config_file.php';

if (isset($_POST['save_winner'])) {
    $team_name = $_POST['team_name'];
    $score = $_POST['score'];
    $date = $_POST['date'];

    // Insert the winner into the winners table
    $sql = "INSERT INTO winners (team, final_score, date) VALUES ('$team_name', '$score', '$date')";

    if ($conn->query($sql) === TRUE) {
        echo "Winner saved successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
