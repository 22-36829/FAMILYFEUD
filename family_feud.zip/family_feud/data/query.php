<?php
include 'config_file.php'; // Include the connection file

if (isset($_POST['save_winner'])) {
    $team_name = $_POST['team_name'];
    $score = $_POST['score'];
    $date = $_POST['date'];

    // Prepare the SQL statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO winners (team, final_score, date) VALUES (?, ?, ?)");
    $stmt->bind_param("sis", $team_name, $score, $date); // "sis" means string, integer, string

    // Execute the statement
    if ($stmt->execute()) {
        echo "Winner saved successfully!";
    } else {
        echo "Error: " . $stmt->error; // Improved error handling
    }

    $stmt->close(); // Close the prepared statement
}

$conn->close(); // Close the connection
?>
